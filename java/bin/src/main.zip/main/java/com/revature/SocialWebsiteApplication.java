package com.revature;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialWebsiteApplication.class, args);
	}
}
