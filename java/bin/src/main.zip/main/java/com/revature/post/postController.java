package com.revature.post;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.revature.user.UserNew;

import ch.qos.logback.core.net.SyslogOutputStream;

@RestController
public class postController {
	
	@Autowired
	private postService PostService;
	
	// Display all posts in homepage
		@RequestMapping("/posts")
		public List<Post> getPost() {
			return PostService.getAllPosts();
		}
		
		//Display all user posts in their profile
		@RequestMapping("/{userId}/posts")
		public List<Post> getPostByUser(@PathVariable Integer userId) {
			return PostService.getPostsByUser(userId);
		}
		
		// User creates new post
		@RequestMapping(method=RequestMethod.POST, value="/{userId}/posts/{postId}")
		public void addPost(@RequestBody Post post, @PathVariable Integer userId) {
			//System.out.println(post.toString());
			post.setUser(new UserNew(userId,"","","","","","",null));
			PostService.addPost(post);
		}
		
		@RequestMapping(method=RequestMethod.PUT, value="/{userId}/posts/{postId}")
		public void updatePost(@RequestBody Post post, @PathVariable Integer userId, @PathVariable Integer postId) {
			//post.setUser(new UserNew(userId,"","","","","","",null));
			PostService.updatePost(post);
		}
		
		@RequestMapping(method=RequestMethod.DELETE, value="/posts/{postId}")
		public void deletePost(@PathVariable Integer postId) {
			PostService.deletePost(postId);
		}
}
