package com.revature.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;

@SessionAttributes("user")
@RestController
public class userController {
	@Autowired
	private userService UserService;
	
	@ModelAttribute("user")
	public UserNew setUpUserForm() {
		return new UserNew();
	}
		
	@RequestMapping("/users")
	public List<UserNew> getAllUsers() {
		return UserService.getAllUser();
	}
	
	@RequestMapping("/users/{id}")
	public UserNew getTopic(@PathVariable Integer id) {
		return UserService.getUser(id);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/users")
	public void addTopic(@RequestBody UserNew user) {
		UserService.addUser(user);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/users/{id}")
	public void updateTopic(@RequestBody UserNew user, @PathVariable Integer id) {
		UserService.updateUser(id, user);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/users/{id}")
	public void deleteTopic(@PathVariable Integer id) {
		UserService.deleteUser(id);
	}
	
	@RequestMapping(method=RequestMethod.POST, value = "/users/login")
	public UserNew Login(@ModelAttribute("user") UserNew user,@RequestParam("username") String username, @RequestParam("password") String password) {
		Integer sesId = 0;
		sesId = UserService.Login(username, password);
		if(sesId != 0) {
			user = UserService.sessionUser(sesId);
			//return "log in";
			return user;
		} else {
			//return "nope";
			return null;
		}
	}
}

