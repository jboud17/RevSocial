package com.revature.config;

public class SecurityConfig {

}
