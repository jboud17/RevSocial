package com.revature.post;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface postRepo extends CrudRepository<Post,Integer> {

	public List<Post> findByUserId(Integer userId);

}
