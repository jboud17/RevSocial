package com.revature.post;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import com.revature.user.UserNew;

@Entity
public class Post {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="postSeq")
	@SequenceGenerator(allocationSize=1, name="postSeq", sequenceName="POST_SEQ")
	private int post_id;
	private String hash;
	private String post_text;	// what is the text of the post
	private String title;
	@ManyToOne(cascade=CascadeType.ALL)
	private UserNew user;
	public int getPost_id() {
		return post_id;
	}
	public void setPost_id(int post_id) {
		this.post_id = post_id;
	}
	public String getHash() {
		return hash;
	}
	public void setHash(String hash) {
		this.hash = hash;
	}
	public String getPost_text() {
		return post_text;
	}
	public void setPost_text(String post_text) {
		this.post_text = post_text;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public UserNew getUser() {
		return user;
	}
	public void setUser(UserNew user) {
		this.user = user;
	}
	public Post() {
	}
	
	public Post(String hash, String post_text, String title) {
		super();
		this.hash = hash;
		this.post_text = post_text;
		this.title = title;
		//this.user = new UserNew(userId,"","","","","","",null);
	}
	
	public Post(String hash, String post_text, String title, Integer userId) {
		super();
		this.hash = hash;
		this.post_text = post_text;
		this.title = title;
		this.user = new UserNew(userId,"","","","","","",null);
	}
	
}