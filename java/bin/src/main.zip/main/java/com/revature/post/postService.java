package com.revature.post;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class postService {
	
	@Autowired	
	private postRepo PostRepo;
	
	public List<Post> getPostsByUser(Integer userId) {
		List<Post> posts = new ArrayList<>();
		PostRepo.findByUserId(userId)
		.forEach(posts::add);
		return posts;
	}
	
	public List<Post> getAllPosts() {
		List<Post> posts = new ArrayList<>();
		PostRepo.findAll()
		.forEach(posts::add);
		return posts;
	}
	
	public Post getPost(Integer id) {
		return PostRepo.findById(id).get();
	}

	public void addPost(Post post) {
		PostRepo.save(post);
	}

	public void updatePost(Post post) {
		PostRepo.save(post);
	}

	public void deletePost(Integer id) {
		PostRepo.deleteById(id);
	}
}
