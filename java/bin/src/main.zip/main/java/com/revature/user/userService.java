package com.revature.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class userService {

	@Autowired
	private userRepo UserRepo;
	
	public List<UserNew> getAllUser(){
		List<UserNew> users = new ArrayList<>();
		UserRepo.findAll()
		.forEach(users::add);
		return users;
	}
	
	
	public UserNew getUser(Integer id) {
		return UserRepo.findById(id).get();
	}

	public void addUser(UserNew user) {
		UserRepo.save(user);
	}

	public void updateUser(Integer id, UserNew user) {
		UserRepo.save(user);
	}

	public void deleteUser(Integer id) {
		UserRepo.deleteById(id);
	}
	
	public Integer Login(String username, String password) {
		String tempUsr;
		String tempPsw;
		tempUsr = UserRepo.findByUsername(username)
		.getUsername();
		tempPsw = UserRepo.findByUsername(username)
		.getPassword();
		if (username == tempUsr && password == tempPsw) {
			Integer tempId = 0;
			tempId = (UserRepo.findByUsername(username).getId());
			//sessionUser(tempId);
			return tempId;
		} else {
			return 0;		
		}
	}
	
	public UserNew sessionUser(Integer sesId) {
		UserNew user = null;
		user = UserRepo.findById(sesId).get();
		return user;
	}
}
